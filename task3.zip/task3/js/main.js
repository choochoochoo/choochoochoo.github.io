function OldSchoolPlayer() {

    this.pathToSrt = 'dz-multimedia-master/subs.srt';

    var TIME_SUB = 5000;
    var TIMEUPDATE_LATENCY = 0.3;

    this.doLoad = function () {

        var element = document.querySelector('.old-school-player');
        var elementVideo = element.querySelector('.old-school-player__video');
        var bgCanvas = element.querySelector('.old-school-player__canvas');
        var bgContext = bgCanvas.getContext('2d');
        var canvas = element.querySelector('.old-school-player__canvas2');
        var context = canvas.getContext('2d');

        var width = null;
        var height = null;

        this.subs = null;

        this.isPauseVideo = false;

        elementVideo.addEventListener('play', playHandler.bind(this), false);

        elementVideo.addEventListener('timeupdate', timeUpdateHandler.bind(this), false);


        getFile.call(this, function (content) {
            var srtParser = new app.srtParser();
            this.subs = srtParser.parseSrt(content);
        }.bind(this));


        function timeUpdateHandler(event) {

            var currentSub = findSub.call(this, event.target.currentTime);

            if (currentSub) {

                elementVideo.pause();
                paintCanvasInBlack();
                this.isPauseVideo = true;
                context.font = "2rem Oranienbaum";
                context.fillStyle = "white";
                context.textAlign = "center";
                context.textBaseline = 'top';
                var lineHeight = 48;
                var y = 0;



                var countString = getCountString(context, currentSub.text, canvas.width / 2, y, canvas.width, lineHeight);
                var topShift = ( ( canvas.height - ( lineHeight * countString  ) ) / 2);
                wrapText(context, currentSub.text, canvas.width / 2, topShift, canvas.width, lineHeight);

                setTimeout(playNext.bind(this), TIME_SUB);
            }



        }

        function playNext(){

            this.isPauseVideo = false;
            elementVideo.play();

        }

        function findSub(time) {

            return this.subs.filter(function(item){
                if(time >= item.end && time <= item.end + TIMEUPDATE_LATENCY){
                    return item;
                }
            })[0];
        }

        function getCountString(context, text, x, y, maxWidth, lineHeight) {

            var count = 0;

            var lines = text.split('\n');

            for (var i = 0; i < lines.length; i++) {

                var words = lines[i].split(' ');
                var line = '';

                for (var n = 0; n < words.length; n++) {
                    var testLine = line + words[n] + ' ';
                    var metrics = context.measureText(testLine);
                    var testWidth = metrics.width;
                    if (testWidth > maxWidth && n > 0) {

                        count++;

                        line = words[n] + ' ';

                    }
                    else {
                        line = testLine;
                    }
                }

                count++;

            }

            return count;
        }

        function wrapText(context, text, x, y, maxWidth, lineHeight) {

            var lines = text.split("\n");

            for (var i = 0; i < lines.length; i++) {

                var words = lines[i].split(' ');
                var line = '';

                for (var n = 0; n < words.length; n++) {
                    var testLine = line + words[n] + ' ';
                    var metrics = context.measureText(testLine);
                    var testWidth = metrics.width;
                    if (testWidth > maxWidth && n > 0) {
                        context.fillText(line, x, y);
                        line = words[n] + ' ';
                        y += lineHeight;
                    }
                    else {
                        line = testLine;
                    }
                }

                context.fillText(line, x, y);
                y += lineHeight;
            }
        }

        function paintCanvasInBlack(){
            context.beginPath();
            context.rect(0, 0, width, height);
            context.fillStyle = 'black';
            context.fill();
        }

        function playHandler() {
            width = elementVideo.clientWidth;
            height = elementVideo.clientHeight;

            canvas.width = width;
            canvas.height = height;

            bgCanvas.width = width;
            bgCanvas.height = height;

            setInterval(makeItGrey.bind(this), 33);


        }

        function getFile(callback) {
            var jsonFile = new XMLHttpRequest();
            jsonFile.open("GET", this.pathToSrt, true);
            jsonFile.send();

            jsonFile.onreadystatechange = function () {
                if (jsonFile.readyState === 4 && jsonFile.status === 200) {
                    callback(jsonFile.responseText);
                }
            }
        }

        function makeItGrey() {

            if (!this.isPauseVideo) {
                bgContext.drawImage(elementVideo, 0, 0, width, height);
                var pixelData = bgContext.getImageData(0, 0, width, height);

                for (var i = 0; i < pixelData.data.length; i += 4) {
                    var r = pixelData.data[i];
                    var g = pixelData.data[i + 1];
                    var b = pixelData.data[i + 2];
                    var averageColour = (r + g + b) / 3;
                    pixelData.data[i] = averageColour;
                    pixelData.data[i + 1] = averageColour;
                    pixelData.data[i + 2] = averageColour;
                }

                context.putImageData(pixelData, 0, 0);
            }


        }
    };

}

var oldSchoolPlayer = new OldSchoolPlayer();


