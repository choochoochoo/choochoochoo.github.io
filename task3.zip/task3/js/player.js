app.Player = function () {

    this.pathToSrt = 'resources/subs/subs.srt';
    this.element = null;
    this.elementVideo = null;
    this.elementAudio = null;
    this.bgCanvas = null;
    this.bgContext = null;
    this.canvas = null;
    this.context = null;
    this.width = 0;
    this.height = 0;

    var requestId;

    // Класс для сцены с субтитрами
    this.subScene = null;

    // Таймер
    this.timer = null;

    // Контролы
    this.controls = null;

    // Аудио
    this.audio = null;

    this.init = function () {

        this.element = document.querySelector('.old-school-player');
        this.elementVideo = this.element.querySelector('.old-school-player__video');
        this.elementVideoOld = this.element.querySelector('.old-school-player__video-old');
        this.elementAudio = this.element.querySelector('.old-school-player__audio');

        this.bgCanvas = this.element.querySelector('.old-school-player__canvas-back');
        this.bgContext = this.bgContext = this.bgCanvas.getContext('2d');
        this.canvas = this.element.querySelector('.old-school-player__canvas');
        this.context = this.context = this.canvas.getContext('2d');

        // Класс для сцены с субтитрами
        this.subScene = new app.SubScene(this, this.canvas, this.context);

        // Таймер
        this.timer = new app.Timer(this);

        // Контролы
        this.controls = new app.Controls(this);

        // Аудио
        this.audio = new app.Audio(this);

        this.elementVideo.addEventListener('timeupdate', timeUpdateHandler.bind(this), false);
        this.elementVideo.addEventListener('canplay', paintPlayer.bind(this), false);
        this.elementVideo.muted = true;

        function timeUpdateHandler(event) {
            this.subScene.getSub(event.target.currentTime);

            if (this.subScene.isSubscene() && !this.subScene.isPlaying()) {
                this.subScene.startSubscene();
            }
        }

        function paintPlayer(event) {
            this.width = this.elementVideo.videoWidth;
            this.height = this.elementVideo.videoHeight;
            //this.width = this.elementVideo.videoWidth / 2;
            //this.height = this.elementVideo.videoHeight / 2;
            this.canvas.width = this.width;
            this.canvas.height = this.height;
            this.bgCanvas.width = this.width;
            this.bgCanvas.height = this.height;
            this.subScene.paintPlayer();
        }

        // Если видео уже есть в кэше
        if (this.elementVideo.readyState > 3) {
            paintPlayer.apply(this);
        }

    };

    function makeItSepia(pixelData) {
        for (var i = 0; i < pixelData.data.length; i += 4) {
            var r = pixelData.data[i];
            var g = pixelData.data[i + 1];
            var b = pixelData.data[i + 2];
            pixelData.data[i] = r * 0.393 + g * 0.769 + b * 0.189;
            pixelData.data[i + 1] = r * 0.349 + g * 0.686 + b * 0.168;
            pixelData.data[i + 2] = r * 0.272 + g * 0.534 + b * 0.131;
        }
    }

    this.applyTexture = function (context) {
        var oldOperation = context.globalCompositeOperation;
        context.globalCompositeOperation = 'multiply';
        context.drawImage(this.elementVideoOld, 0, 0, this.width, this.height);
        context.globalCompositeOperation = oldOperation;
    };

    function renderScene() {

        if (!this.subScene.isSubscene()) {

            this.bgContext.drawImage(this.elementVideo, 0, 0, this.width, this.height);
            this.applyTexture(this.bgContext);

            var pixelData = this.bgContext.getImageData(0, 0, this.width, this.height);
            makeItSepia(pixelData);

            this.context.putImageData(pixelData, 0, 0);

        } else {
            this.subScene.render();
            this.applyTexture(this.context);
        }

        requestId = requestAnimationFrame(renderScene.bind(this));
    }

    this.startRenderScene = function () {
        if (!requestId) {
            renderScene.apply(this);
        }
    };

    this.stopRenderScene = function () {
        if (requestId) {
            cancelAnimationFrame(requestId);
            requestId = null;
        }
    };
};



